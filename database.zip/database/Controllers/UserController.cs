﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using database.Models;

namespace database.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        [HttpGet]
        public ActionResult AddOrEdit(int id = 0)
        {
            registeredUser userModel = new registeredUser();
            return View(userModel);
        }

        [HttpPost]

        public ActionResult AddOrEdit(registeredUser user)
        {
            using (dbModels dbModel = new dbModels())
            {
                dbModel.registeredUser.Add(user);
                dbModel.SaveChanges();
            }

            ViewBag.SuccessMessage = "Registration Succesfull";
            return View("AddOrEdit", new registeredUser());
        }
    }
}